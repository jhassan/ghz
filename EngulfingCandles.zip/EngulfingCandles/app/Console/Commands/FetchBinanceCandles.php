<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use App\Models\Candle;
use Carbon\Carbon;

class FetchBinanceCandles extends Command
{
    protected $signature = 'binance:fetch {symbols=BTCUSDT,ETHUSDT,NEIROUSDT}';
    protected $description = 'Fetch 15-min candlestick data from Binance and save valid bullish engulfing spot candles for multiple coins';

    public function handle()
    {
        
          // 🔁 Hardcoded list of coin pairs
        $symbols = [
            'ACHUSDT', 'ADAUSDT', 'AGLDUSDT', 'AIOZUSDT', 'ALCXUSDT', 'APEUSDT', 'API3USDT', 'APTUSDT', 'ARPAUSDT', 'ASMUSDT'
,'ATAUSDT', 'ATOMUSDT', 'AUCTIONUSDT', 'AVAXUSDT', 'AXSUSDT', 'BADGERUSDT', 'BICOUSDT', 'BITUSDT', 'BOBAUSDT', 'BONDUSDT',
'BTCUSDT', 'BTRSTUSDT', 'C98USDT', 'CHZUSDT', 'CLVUSDT', 'COVALUSDT', 'CROUSDT', 'CTXUSDT', 'DDXUSDT', 'DESOUSDT',
'DIAUSDT', 'DOGEUSDT', 'DOTUSDT', 'DREPUSDT', 'DYPUSDT', 'ELAUSDT', 'ENJUSDT', 'ENSUSDT', 'ERNUSDT', 'ETHUSDT',
'FARMUSDT', 'FETUSDT', 'FIDAUSDT', 'FISUSDT', 'FLOWUSDT', 'FORTUSDT', 'FOXUSDT', 'GALAUSDT', 'GALUSDT', 'GMTUSDT',
'GNOUSDT', 'HBARUSDT', 'HFTUSDT', 'HOPRUSDT', 'ICPUSDT', 'IDEXUSDT', 'IMXUSDT', 'INDEXUSDT', 'JASMYUSDT', 'KRLUSDT',
'KSMUSDT', 'LCXUSDT', 'LINKUSDT', 'LQTYUSDT', 'LRCUSDT', 'MASKUSDT', 'MATHUSDT', 'MATICUSDT', 'MCO2USDT', 'MDTUSDT',
'MEDIAUSDT', 'METISUSDT','MINAUSDT', 'NCTUSDT', 'NEARUSDT', 'NESTUSDT', 'OPUSDT', 'ORNUSDT', 'PAXUSDT', 'PERPUSDT',
'POLSUSDT', 'POLYUSDT', 'PONDUSDT', 'POWRUSDT', 'PRQUSDT', 'QNTUSDT', 'QSPUSDT', 'RADUSDT', 'REQUSDT', 'RLYUSDT',
'RNDRUSDT', 'ROSEUSDT', 'SANDUSDT', 'SHIBUSDT', 'SHPINGUSDT', 'SOLUSDT', 'SPELLUSDT', 'STGUSDT', 'STXUSDT', 'SUKUUSDT',
'SUPERUSDT', 'SYLOUSDT', 'TIMEUSDT', 'TRACUSDT', 'TRUUSDT', 'UPIUSDT', 'USTUSDT', 'VGXUSDT', 'WAMPLUSDT', 'WCFGUSDT',
'WLUNAUSDT', 'XCNUSDT', 'XLMUSDT', 'XRPUSDT', 'XYOUSDT', 'ZENUSDT'
        ];
        $interval = '15m';

        foreach ($symbols as $symbol) {
            $this->info("🔍 Checking symbol: $symbol");

            $response = Http::get("https://api.binance.com/api/v3/klines", [
                'symbol' => $symbol,
                'interval' => $interval,
                'limit' => 73
            ]);

            if (!$response->ok()) {
                $this->error("❌ Failed to fetch data for $symbol");
                continue;
            }

            $candles = $response->json();

            for ($index = 5; $index < count($candles); $index++) {
                $prev = $candles[$index - 1];
                $current = $candles[$index];

                $prevOpen = (float) $prev[1];
                $prevClose = (float) $prev[4];
                $currOpen = (float) $current[1];
                $currClose = (float) $current[4];

                // ✅ Condition 1: Engulfing (green after red, open == prev close, close > prev open)
                $isEngulfing = (
                    $prevOpen > $prevClose &&
                    $currClose > $currOpen &&
                    abs($prevClose - $currOpen) < 0.000001 &&
                    $currClose > $prevOpen
                );

                if (!$isEngulfing) continue;

                // ✅ Condition 2: Spot (curr open < min of last 4 candles' open and close)
                $isSpot = true;
                for ($j = $index - 5; $j < $index - 1; $j++) {
                    $priorOpen = (float) $candles[$j][1];
                    $priorClose = (float) $candles[$j][4];

                    if ($currOpen >= $priorOpen || $currOpen >= $priorClose) {
                        $isSpot = false;
                        break;
                    }
                }

                if (!$isSpot) continue;

                $openTime = Carbon::createFromTimestampMs($current[0])->setTimezone('Asia/Karachi');

                if (Candle::where('symbol', $symbol)->where('open_time', $openTime)->exists()) {
                    continue;
                }

                Candle::create([
                    'symbol' => $symbol,
                    'interval' => $interval,
                    'open_time' => $openTime,
                    'open' => $currOpen,
                    'high' => (float) $current[2],
                    'low' => (float) $current[3],
                    'close' => $currClose,
                    'is_bullish_engulfing' => true
                ]);

                $this->info("✅ [$symbol] Engulfing Spot Candle at: $openTime | O: $currOpen C: $currClose");
            }
        }

        $this->info("🎯 Finished scanning all symbols.");
    }
}
