

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>📊 Bullish Engulfing Spot Candles</h2>

    <form method="GET" class="form-inline mb-4">
        <label for="symbol" class="mr-2">Filter by Symbol:</label>
        <select name="symbol" id="symbol" class="form-control mr-2">
            <option value="">-- All --</option>
            <?php $__currentLoopData = $symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($symbol); ?>" <?php echo e(request('symbol') == $symbol ? 'selected' : ''); ?>>
                    <?php echo e($symbol); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit" class="btn btn-primary">Filter</button>
    </form>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Symbol</th>
                <th>Interval</th>
                <th>Open Time</th>
                <th>Open</th>
                <th>High</th>
                <th>Low</th>
                <th>Close</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $candles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($candle->symbol); ?></td>
                    <td><?php echo e($candle->interval); ?></td>
                    <td><?php echo e($candle->open_time); ?></td>
                    <td><?php echo e($candle->open); ?></td>
                    <td><?php echo e($candle->high); ?></td>
                    <td><?php echo e($candle->low); ?></td>
                    <td><?php echo e($candle->close); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">No records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($candles->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\EngulfingCandles\EngulfingCandles\resources\views/candles/index.blade.php ENDPATH**/ ?>